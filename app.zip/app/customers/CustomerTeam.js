import {Col, Image, Row, Table} from "react-bootstrap";
import TeamImg from "../../assets/team.png";
import BulletList from "../../components/BulletList";
import React from "react";

export default function CustomerTeam({details}) {
  return (
    <>
      <div className={'row_detail'}>
        <div className={'impact_content row'}>
          <Row className={'align-items-center'}>
            <Col sm={6} xs={12}>
              <Image src={TeamImg}/>
            </Col>
            <Col sm={6} xs={12}>
              <BulletList list={details.timeline}/>
            </Col>
          </Row>
        </div>
      </div>
      <div className={'wave'}/>
      <div className={'heading bg-yellow'}>
        <h5>Team SLK</h5>
      </div>
      <div className={'profiles'}>
        <Row>
          {details.slk_team.map((k, v) => (
            <Col xs={12} sm={6} className={'mb-4'}>
              <div className={'team-profile'}>
                <Image src={k.avatar}/>
                <div className={'info yellow'}>
                  <h5>{k.name}</h5>
                  <h6>{k.description}</h6>
                  <Table borderless responsive>
                    <tbody>
                    <tr>
                      <td>Email Id</td>
                      <td>: {k.email}</td>
                    </tr>
                    <tr>
                      <td>Phone</td>
                      <td>: {k.contact}</td>
                    </tr>
                    </tbody>
                  </Table>
                </div>
              </div>
            </Col>
          ))}
        </Row>
      </div>
      <div className={'heading bg-blue'}>
        <h5>Team {details.title}</h5>
      </div>
      <div className={'profiles'}>
        <Row>
          {details.client_team.map((k, v) => (
            <Col key={v.toString()} xs={12} sm={6} className={'mb-4'}>
              <div className={'team-profile'}>
                <Image src={k.avatar} className={'blue'}/>
                <div className={'info blue'}>
                  <h5>{k.name}</h5>
                  <h6>{k.description}</h6>
                  <Table borderless responsive>
                    <tbody>
                    <tr>
                      <td>Email Id</td>
                      <td>: {k.email}</td>
                    </tr>
                    <tr>
                      <td>Phone</td>
                      <td>: {k.contact}</td>
                    </tr>
                    </tbody>
                  </Table>
                </div>
              </div>
            </Col>
          ))}
        </Row>
      </div>
    </>
  )
}
