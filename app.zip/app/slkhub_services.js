import axios from "axios";

class Service {
 getcustdetails() {
  return axios.get('https://localhost:44304/api/GetCustomers');
  }
 getlearningdetails() {
  return axios.get('https://localhost:44304/api/GetLearnings');
  }
 getevolofficedetails() {
  return axios.get('https://localhost:44304/api/GetEvolutionDocuments');
  }
 getevolfocusdetails() {
  return axios.get('https://localhost:44304/api/GetEvolutionStrategicFocus');
  }
  getethosbeliefdetails(){
  return axios.get('https://localhost:44304/api/GetEthosDocumentsLevel1/Item level 1');
  }
   getethosvaluesdetails(){
  return axios.get('https://localhost:44304/api/GetEthosDocumentsLevel2/Item level 2');
  }
  getethoscultureInnovationdetails(){
  return axios.get('https://localhost:44304/api/GetEthosCulture_Innovation/Innovation');
  }
  getethoscultureUniquedetails(){
  return axios.get('https://localhost:44304/api/GetEthosCulture_Unique/Unique');
  }
  getethoscultureFundetails(){
  return axios.get('https://localhost:44304/api/GetEthosCulture_Fun/Fun');
  }
  getemployeejournyetails(){
  return axios.get('https://localhost:44304/api/GetEmployeeJourney');
  }
}
const ser = new Service();
export default ser;
