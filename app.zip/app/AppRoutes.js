import React, {lazy, Suspense} from 'react'
import {Route, Switch, useParams} from 'react-router-dom'
import {Spinner} from "react-bootstrap";


const Home = lazy(() => import('./home/Home'))
const EthosBelief = lazy(() => import('./ethos/EthosBelief'))
const EthosValues = lazy(() => import('./ethos/EthosValues'))
const EthosCulture = lazy(() => import('./ethos/EthosCulture'))
const Learnings = lazy(() => import('./learnings/Learnings'))
const Peoples = lazy(() => import('./peoples/Peoples'))
const College = lazy(() => import('./peoples/College'))
const Blend = lazy(() => import('./peoples/Blend'))
const Career = lazy(() => import('./peoples/Career'))

const Impact = lazy(() => import("./impact/Impact"))
const Evolution = lazy(() => import("./evolution/Evolution"))
const Customers = lazy(() => import("./customers/Customers"))
const CustomerDetails = lazy(() => import("./customers/CustomerDetails"))


function AppRoutes() {
  let {impact_slug} = useParams();

  return (
    <Suspense fallback={<div className={'d-flex justify-content-center align-items-center'} style={{height: '90vh'}}>
      <Spinner animation="border"/>
    </div>}>
      <Switch>
        <Route exact path="/" component={Home}/>
        <Route exact path="/ethos/belief-philosophy/" component={EthosBelief}/>
        <Route exact path="/ethos/belief-philosophy/" component={EthosBelief}/>
        <Route exact path="/ethos/values/" component={EthosValues}/>
        <Route exact path="/ethos/culture/" component={EthosCulture}/>
        <Route exact path="/learnings/" component={Learnings}/>
        <Route exact path="/people/" component={Peoples}/>
        <Route exact path="/people/blend/" component={Blend}/>
        <Route exact path="/people/Career" component={Career}/>

        <Route exact path="/people/college/" component={College}/>
        <Route exact path="/impact/" component={Impact}/>
        <Route exact path="/evolution/" component={Evolution}/>
        <Route exact path="/customers/" component={Customers}/>
        <Route exact path="/customers/:customer_slug/" component={CustomerDetails}/>
      </Switch>
    </Suspense>
  )
}

export default AppRoutes
